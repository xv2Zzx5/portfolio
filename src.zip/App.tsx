import "./App.css";
import Button from "./components/Button";
import { Link } from "react-router-dom";
function App() {
    return (
        <div>
            <Link to="/ui">
                <Button variant="primary">go ui</Button>
            </Link>
        </div>
    );
}

export default App;
